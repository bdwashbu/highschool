glTetris 2.1
By Brian Washburn, December 6th, 2002

I do not hold any responsibility for damage this may (wont) cause to your computer.

Songs By Necros

Greater than a Pentium 400 recommended
Greater than a TNT recommended

Up flips piece
Left move piece left
Right moves piece right
Down makes the piece fall down instantly
Space makes piece hurry up
Enter Pauses

Version 1.0 - released october 21, 2002

Version 1.1 - 1.2 ***NOVEMBER 11th, 2002*** RELEASED
	Fixed bugs with pieces moving out of boundries, causing crash
	New Level system
	Updated particle system, faster, better
	Added Pause
	Added Level-up bar
	Added better sounds
	Added explosion sound, light
	General Speedup tweaks
	Added gameover
	Added down-button graphical fix
	Brightened the blocks
	Made block outlines look better
	Added Load() function
	Implemented linked lists for particles and lightmaps
	Added color smoothing between the squares
	Added title screen backround, and nagivation
	Added music, midi *changed to .s3m*
	Added backround
	Made text look much better, black outline
Version 1.2 - 2.0 ***NOVEMBER 26th*** RELEASED
	Tweaked block movement
	Added black outline to the block you control
	Grid outline code much, much more efficent
	Added code for more than one song
	now uses GL_CLAMP_TO_EDGE
	Made titlescreen look prettier
	Got restarting down
	Highscore name input
	fixed potential memory leak
	added music to opening and sounds
	Inproved collision detection code
	High Score list, with snow :)
Version 2.0 - 3.0 Beta Testing
	Vastly improved blockclass efficiency
	Improved collision detection again
	More Songs, added song control
	Made blocks of same type, same color
	Decreased Explosion time
	Improved initial input
	Fixed some startup issues
	added flaming menu at start
	added side waterbar

**Need to**

New Sounds*
Music*
Power-ups
Backrounds*
High-Score list*

****