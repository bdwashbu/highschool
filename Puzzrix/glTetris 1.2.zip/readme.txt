glTetris
By Brian Washburn, 2002

Up flips piece
Left move piece left
Right moves piece right
Down makes the piece fall down instantly
Space makes piece hurry up
Enter Pauses

Version 1.0 - released october 21, 2002

Version 1.1 - 1.2 ***NOVEMBER 11th, 2002*** RELEASED
	Fixed bugs with pieces moving out of boundries, causing crash
	New Level system
	Updated particle system, faster, better
	Added Pause
	Added Level-up bar
	Added better sounds
	Added explosion sound, light
	General Speedup tweaks
	Added gameover
	Added down-button graphical fix
	Brightened the blocks
	Made block outlines look better
	Added Load() function, waiting for load until game initializes, unlike before
	Now uses linked lists for particles and lightmaps, like I should have had it...duh
	Added color smoothing between the squares, looks better
	Added title screen backround, and nagivation
	Added music, midi *changed to .s3m*
	Added backround
	Made text look much better
Version 1.2 - ???

**Need to**

New Sounds 
Music *check*
Power-ups
Backrounds *check*