hey chris

my newest little game based on yahoo pool

some last minute bugs popped up, but you can still make levels with the editor.  Save any levels you make as "brian", or else the game will not load it.